package com.example.simpleauth;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText etName = findViewById(R.id.etName);
        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        Button btnRegister = findViewById(R.id.btnRegister);

        // Go back to Login screen
        findViewById(R.id.tvGoLogin).setOnClickListener(v -> finish());

        btnRegister.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                toast("Please fill in all fields");
                return;
            }

            JSONObject body = new JSONObject();
            try {
                body.put("full_name", name);
                body.put("email", email);
                body.put("password", password);
            } catch (Exception ignored) { }

            btnRegister.setEnabled(false);

            ApiClient.request("POST", "school_api/api/register.php", body, null, new ApiClient.Callback() {
                @Override
                public void onResponse(int code, JSONObject json) {
                    btnRegister.setEnabled(true);

                    if (code == 200 || code == 201) {
                        toast("Registered! Please log in.");
                        finish(); // back to Login
                    } else {
                        toast(json.optString("message", "Registration failed (" + code + ")"));
                    }
                }

                @Override
                public void onError(String message) {
                    btnRegister.setEnabled(true);
                    toast("Network error: " + message);
                }
            });
        });
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}