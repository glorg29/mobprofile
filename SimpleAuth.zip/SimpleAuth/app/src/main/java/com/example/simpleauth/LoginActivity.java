package com.example.simpleauth;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity {

    private SessionManager session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = new SessionManager(this);

        // Already logged in? Skip to profile.
        if (session.getToken() != null) {
            openProfile();
            return;
        }

        setContentView(R.layout.activity_login);

        EditText etEmail = findViewById(R.id.etEmail);
        EditText etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);

        findViewById(R.id.tvGoRegister).setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class)));

        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString();

            if (email.isEmpty() || password.isEmpty()) {
                toast("Please fill in all fields");
                return;
            }

            JSONObject body = new JSONObject();
            try {
                body.put("email", email);
                body.put("password", password);
            } catch (Exception ignored) { }

            btnLogin.setEnabled(false);

            ApiClient.request("POST", "school_api/api/login.php", body, null, new ApiClient.Callback() {
                @Override
                public void onResponse(int code, JSONObject json) {
                    btnLogin.setEnabled(true);
                    String token = json.optString("token", null);

                    if (code == 200 && token != null) {
                        session.saveToken(token);
                        openProfile();
                    } else {
                        toast(json.optString("message", "Invalid email or password"));
                    }
                }

                @Override
                public void onError(String message) {
                    btnLogin.setEnabled(true);
                    toast("Network error: " + message);
                }
            });
        });
    }

    private void openProfile() {
        startActivity(new Intent(this, ProfileActivity.class));
        finish();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}