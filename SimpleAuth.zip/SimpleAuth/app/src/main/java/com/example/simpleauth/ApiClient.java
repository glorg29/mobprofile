package com.example.simpleauth;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ApiClient {

    // Emulator: 10.0.2.2 = your PC's localhost
    // Real phone: use your PC's LAN IP, e.g. http://192.168.1.5:8000/
    private static final String BASE_URL = "http://10.0.2.2/";

    private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());

    public interface Callback {
        void onResponse(int code, JSONObject json); // runs on UI thread
        void onError(String message);               // runs on UI thread
    }

    public static void request(String method, String path, JSONObject body,
                               String token, Callback cb) {
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(BASE_URL + path);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod(method);
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(10000);
                conn.setRequestProperty("Accept", "application/json");

                if (token != null) {
                    conn.setRequestProperty("Authorization", "Bearer " + token);
                }

                // Send JSON body (POST requests)
                if (body != null) {
                    conn.setDoOutput(true);
                    conn.setRequestProperty("Content-Type", "application/json");
                    try (OutputStream os = conn.getOutputStream()) {
                        os.write(body.toString().getBytes(StandardCharsets.UTF_8));
                    }
                }

                int code = conn.getResponseCode();
                InputStream is = (code >= 200 && code < 300)
                        ? conn.getInputStream()
                        : conn.getErrorStream();

                // Read response text
                StringBuilder sb = new StringBuilder();
                if (is != null) {
                    try (BufferedReader br = new BufferedReader(
                            new InputStreamReader(is, StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = br.readLine()) != null) {
                            sb.append(line);
                        }
                    }
                }

                JSONObject json = sb.length() > 0
                        ? new JSONObject(sb.toString())
                        : new JSONObject();

                mainHandler.post(() -> cb.onResponse(code, json));

            } catch (Exception e) {
                mainHandler.post(() -> cb.onError(e.getMessage()));
            } finally {
                if (conn != null) conn.disconnect();
            }
        });
    }
}