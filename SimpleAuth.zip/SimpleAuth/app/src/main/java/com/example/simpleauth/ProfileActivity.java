package com.example.simpleauth;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONObject;

public class ProfileActivity extends AppCompatActivity {

    private static final String TAG = "PROFILE";

    private SessionManager session;
    private TextView tvName;
    private TextView tvEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        session = new SessionManager(this);

        tvName = findViewById(R.id.tvName);
        tvEmail = findViewById(R.id.tvEmail);

        findViewById(R.id.btnLogout).setOnClickListener(v -> logout());

        // No token saved? Go back to login.
        if (session.getToken() == null) {
            logout();
            return;
        }

        loadProfile();
    }

    private void loadProfile() {
        ApiClient.request("GET", "school_api/api/profile.php", null, session.getToken(), new ApiClient.Callback() {
            @Override
            public void onResponse(int code, JSONObject json) {
                // Shows the raw response in Logcat (search "PROFILE")
                Log.d(TAG, "Code: " + code + " Body: " + json.toString());

                if (code == 200) {
                    JSONObject user = extractUser(json);

                    String fullName = user.optString("full_name", "");
                    String email = user.optString("email", "");

                    tvName.setText(fullName.isEmpty() ? "-" : fullName);
                    tvEmail.setText(email.isEmpty() ? "-" : email);

                } else if (code == 401) {
                    toast("Session expired. Please log in again.");
                    logout();
                } else {
                    tvName.setText("Could not load profile");
                    toast("Failed to load profile (" + code + ")");
                }
            }

            @Override
            public void onError(String message) {
                Log.e(TAG, "Network error: " + message);
                tvName.setText("Could not load profile");
                toast("Network error: " + message);
            }
        });
    }

    // Handles flat {"full_name":...} or nested {"user":{...}} / {"data":{...}}
    private JSONObject extractUser(JSONObject json) {
        if (json.optJSONObject("user") != null) {
            return json.optJSONObject("user");
        }
        if (json.optJSONObject("data") != null) {
            JSONObject data = json.optJSONObject("data");
            // Handles {"data":{"user":{...}}}
            if (data.optJSONObject("user") != null) {
                return data.optJSONObject("user");
            }
            return data;
        }
        return json;
    }

    private void logout() {
        session.clear();
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}